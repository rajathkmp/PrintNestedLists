__author__ = 'RK'

from distutils.core import setup

setup(
    name='PrintNestedLists',
    version='1.0.0',
    py_modules=['printlistall'],
    author='RajathKumar',
    author_email='rajathkumar.exe@gmail.com',
    url='http:/www.rajathkumar.com',
    description='Print Nested lists with two functions printtab() with tabspace printnotab() without tabspace')